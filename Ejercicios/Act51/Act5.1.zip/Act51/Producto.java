package Act51;

/**
 * @author Manuel Martín Gimeno
 * 
 */
public class Producto {
	
	//Attributes
	private String fechaCaducidad;
	private int numeroDeLote;

	//Builders
	public Producto(String fechaCaducidad, int numeroDeLote) {
		this.fechaCaducidad = fechaCaducidad;
		this.numeroDeLote = numeroDeLote;
	}	
	

}
