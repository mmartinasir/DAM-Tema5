package Act52;
/**
 * @author Manuel Martin Gimeno
 */
public class Fecha {
	
	//Attributes
	private int dia;
	private int mes;
	private int año;

	//Builders
	public Fecha(int dia, int mes, int año) {
		this.dia = dia;
		this.mes = mes;
		this.año = año;
	}

}
