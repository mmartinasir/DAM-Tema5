package Act52;
/**
 * @author Manuel Martin Gimeno
 */
public class ListaDeProducto {

	// Attributes
	private ProductoListable tope;

	// Builders
	public ListaDeProducto() {
		this.tope = null;
	}

	// Getters and Setters
	public ProductoListable getTope() {
		return tope;
	}

	public void setTope(ProductoListable tope) {
		this.tope = tope;
	}

	// Methods
	public void push(ProductoListable p) {
		if (this.tope == null) {
			this.tope = p;
		} else {
			p.setProductoAnterior(this.tope);
			this.tope = p;
		}
	}
		
	public double precioTotal() {
		double result = 0.0;
		ProductoListable aux = this.tope;
		while (aux != null) {
			result = result+aux.getPrecioUnitario();
			aux = aux.getProductoAnterior();
		}
		return result;
	}
	
	public ProductoListable search(String s) {
		ProductoListable result = this.tope;
		while (result.getDescripcion().equals(s) == false) {
			result = result.getProductoAnterior();
		}
		return result;
	}

}
